/* eslint-disable indent */
/* eslint-disable multiline-ternary */
import React from "react";
import Users from "./components/users";

function App() {
    return <Users />;
}

export default App;
