import users from "./fake.api/user.api";
import professions from "./fake.api/professions.api";
const API = {
    users,
    professions
};
export default API;
